create trigger TIG_MOBILE_LOG
  before insert
  on MOBILE_LOG
  for each row
  when (new.id is null)
  begin

select SEQ_MOBILE_LOG.nextval into :new.id from dual;

end;
/

