create function fun_VideoSFFX(spIds in  varchar2,startTimes in varchar2) return NUMBER
is
video_Num NUMBER;
begin
select count(*) into video_Num from VIDEO_RECORD t where spid=spIds and startTime<=to_date(startTimes,'yyyy-mm-dd');
return video_Num;
end;

 
/

