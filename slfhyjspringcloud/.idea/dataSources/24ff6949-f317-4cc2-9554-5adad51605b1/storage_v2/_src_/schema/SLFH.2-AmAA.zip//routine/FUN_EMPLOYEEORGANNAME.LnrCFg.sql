create function fun_EmployeeOrganName(userIds in  varchar2) return varchar2
is
roleNames varchar2(1000);
begin
select t.organizationname into roleNames from organizationinfo t,employee_organization t1 where t.organizationid=t1.organizationid and t1.employeeid=userIds;
return roleNames;
end;

 
/

