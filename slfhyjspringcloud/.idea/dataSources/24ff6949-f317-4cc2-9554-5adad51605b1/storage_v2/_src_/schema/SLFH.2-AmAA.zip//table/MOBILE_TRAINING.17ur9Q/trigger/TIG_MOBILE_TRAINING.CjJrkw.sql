create trigger TIG_MOBILE_TRAINING
  before insert
  on MOBILE_TRAINING
  for each row
  when (new.id is null)
  begin
  select SEQ_MOBILE_TRAINING.nextval into :new.id from dual;
end;
/

