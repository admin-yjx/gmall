create function fun_VideoGlbm(spId in  varchar2) return varchar2
is
videoInfo varchar2(1000);
begin
select t.glbm into videoInfo from SXQXX t where t.sbbh=spId;
return videoInfo;
end;

 
/

