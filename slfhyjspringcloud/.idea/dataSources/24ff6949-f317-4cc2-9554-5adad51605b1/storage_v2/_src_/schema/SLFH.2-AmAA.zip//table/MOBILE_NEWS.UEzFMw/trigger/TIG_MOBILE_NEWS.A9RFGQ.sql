create trigger TIG_MOBILE_NEWS
  before insert
  on MOBILE_NEWS
  for each row
  when (new.id is null)
  begin

select SEQ_MOBILE_NEWS.nextval into :new.id from dual;

end;
/

