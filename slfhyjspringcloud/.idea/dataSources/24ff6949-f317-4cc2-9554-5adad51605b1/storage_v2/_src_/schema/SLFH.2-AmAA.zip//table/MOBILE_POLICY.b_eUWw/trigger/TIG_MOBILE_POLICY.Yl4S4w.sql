create trigger TIG_MOBILE_POLICY
  before insert
  on MOBILE_POLICY
  for each row
  when (new.id is null)
  begin
  select SEQ_MOBILE_POLICY.nextval into :new.id from dual;
end;
/

