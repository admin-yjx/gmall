create function fun_EmployeeRoleName(userIds in  varchar2) return varchar2
is
roleNames varchar2(1000);
begin
select listagg(t2.roleName, ',') within GROUP(order by t2.roleName) roleName into roleNames
from (select roleName  from roleinfo t,user_role t1 where t.roleid=t1.roleid and t1.userid=userIds) t2;
return roleNames;
end;

 
/

