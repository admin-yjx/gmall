create function video_UserLoginName(UserNameId in  varchar2) return varchar2
is
UserName varchar2(100);
begin
select t.username into UserName from USERINFO t where t.userid=UserNameId;
return UserName;
end;

 
/

