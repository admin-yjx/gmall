create trigger TIG_MOBILE_EXCEPTABLE
  before insert
  on MOBILE_EXCEPTABLE
  for each row
  when (new.id is null)
  begin
  select SEQ_MOBILE_EXCEPTABLE.nextval into :new.id from dual;
end;
/

