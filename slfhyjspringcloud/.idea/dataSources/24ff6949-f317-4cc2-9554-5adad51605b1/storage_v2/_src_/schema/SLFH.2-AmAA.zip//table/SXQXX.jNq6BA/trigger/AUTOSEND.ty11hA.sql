create trigger AUTOSEND
  after update of SBZT
  on SXQXX
  for each row
  when (old.sbzt = 0)
  declare
  tempid varchar2(20);
  tempspid varchar2(70);
begin
  select (SPJK_RECORD.NEXTVAL) into tempid from dual;
  IF  :NEW.sbzt =1 THEN
      insert into video_record(id,spid,starttime,break,note,senderid) values(tempid,:old.sbbh,sysdate,'其他','','machine01');
      select NVL(max(steps),0) into tempspid from video_recordinfo where taskid=tempid;
      insert into video_recordinfo (steps,spjkinfo,taskid,id,infotime)values(tempspid+1,'系统检测有故障',tempid,SPJK_RECORDINFO.NEXTVAL,sysdate);
     
      END IF;
END AUTOSEND;

/

