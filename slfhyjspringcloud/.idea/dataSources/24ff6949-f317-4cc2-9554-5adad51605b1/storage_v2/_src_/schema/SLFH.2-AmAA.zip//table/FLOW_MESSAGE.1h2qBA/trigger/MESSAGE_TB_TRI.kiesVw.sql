create trigger MESSAGE_TB_TRI
  before insert
  on FLOW_MESSAGE
  for each row
  begin   /*触发器开始*/
select  message_tb_seq.nextval into :new.id from dual;
/*触发器主题内容，即触发后执行的动作，在此是取得序列dectuser_tb_seq的下一个值插入到表dectuser中的userid字段中*/
end;

/

