create trigger TIG_LX_TASK
  before insert
  on LX_TASK
  for each row
  when (new.id is null)
  begin

select SEQ_LX_TASK.nextval into :new.id from dual;

end;
/

