create function fun_VideoRole(userIds in  varchar2) return varchar2
is
roleNames varchar2(1000);
begin
select roleName into roleNames from  (select * from USER_ROLE t,ROLEINFO t1 where t.roleid=t1.roleid)t2 where t2.userid=userIds;
return roleNames;
end;

 
/

