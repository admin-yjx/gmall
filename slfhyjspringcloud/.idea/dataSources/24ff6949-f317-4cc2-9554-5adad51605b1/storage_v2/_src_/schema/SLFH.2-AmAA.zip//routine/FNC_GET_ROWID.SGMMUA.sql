create function fnc_get_rowid return varchar2 is
  Result        varchar2(2000) := '';
  ResultDefault varchar2(20) := 'R0000001';
  cnt           integer := 0;
  prefixStr     varchar2(2) := 'R';
  roidLen       integer := 7;

begin

  begin
    select prefixStr ||
           LPAD(max(to_number(NVL(replace(roleid, prefixStr, ''), '0'))) + 1,
                roidLen,
                '0')
      into Result
      from roleinfo ;
  
    if Result = prefixStr then
      Result := ResultDefault;
    end if;
  
  exception
    when no_data_found then
      Result := ResultDefault;
    when OTHERS THEN
      Result := ResultDefault;
  end;

  return Result;
end fnc_get_rowid;

 
/

