create trigger TIG_USERINFO
  before insert
  on USERINFO
  for each row
  when (new.id is null)
  begin
select SEQ_USERINFO.nextval into :new.id from dual;
end;
/

