create trigger TRIGGER_FLOW_TEMPLATE
  before insert
  on FLOW_TEMPLATE
  for each row
  when (NEW.id IS NULL)
  BEGIN

   SELECT s_flow_template.NEXTVAL INTO:NEW.id FROM DUAL;

END;

/

