create trigger TIG_MOBILE_UPLOAD
  before insert
  on MOBILE_UPLOADFILE
  for each row
  when (new.id is null)
  begin
select SEQ_MOBILE_UPLOADFILE.nextval into :new.id from dual;
end;
/

