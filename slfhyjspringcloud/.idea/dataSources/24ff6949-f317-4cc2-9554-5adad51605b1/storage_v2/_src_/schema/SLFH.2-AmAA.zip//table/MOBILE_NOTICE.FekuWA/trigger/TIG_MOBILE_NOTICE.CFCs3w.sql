create trigger TIG_MOBILE_NOTICE
  before insert
  on MOBILE_NOTICE
  for each row
  when (new.id is null)
  begin
  select SEQ_MOBILE_NOTICE.nextval into :new.id from dual;
end;
/

