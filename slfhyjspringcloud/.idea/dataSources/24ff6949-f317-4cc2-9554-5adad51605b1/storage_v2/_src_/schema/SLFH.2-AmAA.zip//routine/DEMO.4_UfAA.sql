create procedure demo
as
n_count number:=0;
begin
  if n_count<5 then
  dbms_output.put_line(n_count);
  n_count:=n_count+1;
  dbms_output.put_line(n_count);
  end if;
  end;

 
/

