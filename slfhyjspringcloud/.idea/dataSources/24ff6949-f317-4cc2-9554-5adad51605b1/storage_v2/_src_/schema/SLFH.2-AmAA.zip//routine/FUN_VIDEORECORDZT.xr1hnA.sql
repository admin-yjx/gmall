create function fun_VideoRecordZT(zt in  varchar2) return varchar2
is
ZtName varchar2(1000);
begin
  if zt='0' THEN
    ZtName:='未派发';
  elsif zt='1' THEN
     ZtName:='已派单';
  elsif zt='2' THEN
     ZtName:='已接受';
  elsif zt='3' THEN
     ZtName:='已提交审核';
  elsif zt='4' THEN
     ZtName:='未通过审核';
  elsif zt='5' THEN
     ZtName:='完成任务';
  else 
    ZtName:='消单';
  end if;
return ZtName;
end;

 
/

