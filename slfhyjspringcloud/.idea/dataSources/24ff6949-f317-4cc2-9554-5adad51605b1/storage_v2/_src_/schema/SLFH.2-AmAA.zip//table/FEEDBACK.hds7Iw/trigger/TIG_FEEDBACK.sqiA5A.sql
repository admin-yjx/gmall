create trigger TIG_FEEDBACK
  before insert
  on FEEDBACK
  for each row
  when (new.id is null)
  begin

select SEQ_FEEDBACK.nextval into :new.id from dual;

end;
/

