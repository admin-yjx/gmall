create function video_UserName(UserNameId in  varchar2) return varchar2
is
UserName varchar2(100);
begin
select t.EMPLOYEENAME into UserName from EMPLOYEEINFO t where t.EMPLOYEEID=UserNameId;
return UserName;
end;

 
/

