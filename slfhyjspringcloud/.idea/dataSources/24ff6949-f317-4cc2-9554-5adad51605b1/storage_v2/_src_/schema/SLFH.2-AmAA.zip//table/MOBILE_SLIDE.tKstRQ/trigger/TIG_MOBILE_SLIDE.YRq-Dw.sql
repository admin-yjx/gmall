create trigger TIG_MOBILE_SLIDE
  before insert
  on MOBILE_SLIDE
  for each row
  when (new.id is null)
  begin
  select SEQ_MOBILE_SLIDE.nextval into :new.id from dual;
end;
/

