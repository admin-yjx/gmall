create trigger TRIGGER_FLOW_NODE
  before insert
  on FLOW_PROCEDURE
  for each row
  when (NEW.id IS NULL)
  BEGIN

   SELECT s_flow_node.NEXTVAL INTO:NEW.id FROM DUAL;

END;

/

