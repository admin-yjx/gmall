create trigger TRIGGER_FLOW_ROLE
  before insert
  on FLOW_ROLE
  for each row
  when (NEW.id IS NULL)
  BEGIN

   SELECT s_flow_role.NEXTVAL INTO:NEW.id FROM DUAL;

END;

/

