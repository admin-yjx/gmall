create trigger TR_LX_GLB
  before insert
  on LX_GLB
  for each row
  begin

select lx_glb_seq.nextval into :new.id from dual;

end;
/

