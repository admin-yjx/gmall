create function fun_VideoInfo(rwId in  varchar2) return varchar2
is
videoInfo varchar2(1000);
begin
select t.SPJKINFO into videoInfo from VIDEO_RECORDINFO t where t.taskid=rwId and steps=(select max(steps) from VIDEO_RECORDINFO where taskid=rwId);
return videoInfo;
end;

 
/

