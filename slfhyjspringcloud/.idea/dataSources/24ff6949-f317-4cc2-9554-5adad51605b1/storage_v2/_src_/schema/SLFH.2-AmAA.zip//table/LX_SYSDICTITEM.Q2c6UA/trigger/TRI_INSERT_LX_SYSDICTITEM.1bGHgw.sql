create trigger TRI_INSERT_LX_SYSDICTITEM
  before insert
  on LX_SYSDICTITEM
  for each row
  begin
select BSM_sequence.nextval into :new.BSM from dual;         -- 注：sv_id 同上
end;

/

