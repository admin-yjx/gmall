create FUNCTION BlobToClob(blob_in IN BLOB) RETURN CLOB AS
  v_clob    CLOB;
  v_varchar clob := '';
  v_start   PLS_INTEGER := 1;
  v_buffer  PLS_INTEGER := 115532767;
  
         l_lang    NUMBER := DBMS_LOB.default_lang_ctx;
     i_dest_offset number := 1;
      i_src_offset  number :=1;
     l_warning NUMBER;
BEGIN
  DBMS_LOB.CREATETEMPORARY(v_clob, TRUE);
  for i in 1 .. DBMS_LOB.GETLENGTH(blob_in) loop
    v_clob := v_clob || '邓';
  end loop;

  dbms_lob.convertToBlob(blob_in,
                            v_clob,
                           dbms_lob.lobmaxsize,
                           i_dest_offset,
                           i_src_offset,
                           DBMS_LOB.default_csid,
                           l_lang,
                           l_warning);
  RETURN v_clob;
END BlobToClob;

 
/

