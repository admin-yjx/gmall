create trigger TIG_MOBILE_HELP
  before insert
  on MOBILE_HELP
  for each row
  when (new.id is null)
  begin
  select SEQ_MOBILE_HELP.nextval into :new.id from dual;
end;
/

